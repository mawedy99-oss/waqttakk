# Waqtk web

Static user-facing website (single page, no build step).

## Deploy on GitHub Pages
1. Create a repository (for example `waqtk-web`) and upload the contents of this folder to its root.
   Keep `index.html`, `.nojekyll` and `README.md` at the top level.
2. Repository Settings → Pages → Build and deployment → Source: "Deploy from a branch", branch `main`, folder `/ (root)`.
3. After a minute the site is live at `https://<your-user>.github.io/waqtk-web/`.

## Notes
- Navigation uses URL hashes (`#home`, `#store`, `#book`…), so no server-side routing is needed.
- Data is sample data stored in the page. Bookings, orders, coupons and chat are not yet connected to the API (see the separate `waqtk-api` project).
- Fonts load from Google Fonts; an internet connection is required for the Rubik font.
